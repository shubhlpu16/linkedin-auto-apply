document.addEventListener('DOMContentLoaded', async () => {
        const startBtn = document.getElementById('startBtn')
        const startBtnLabel = startBtn?.querySelector('.btn__label')
        const stopBtn = document.getElementById('stopBtn')
        const saveSettingsBtn = document.getElementById('saveSettings')
        const skillsContainer = document.getElementById('skillsContainer')
        const addSkillBtn = document.getElementById('addSkillBtn')

        const statusBadge = document.getElementById('statusBadge')
        const statusText = document.getElementById('statusText')
        const statusHint = document.getElementById('statusHint')

        const appliedCountEl = document.getElementById('appliedCount')
        const skippedCountEl = document.getElementById('skippedCount')
        const runTimerEl = document.getElementById('runTimer')
        const resetBtn = document.getElementById('resetBtn')

        const countdownContainer = document.getElementById('countdownContainer')
        const countdownRing = document.getElementById('countdownRing')
        const countdownValueEl = document.getElementById('countdownValue')
        const countdownLabelEl = document.getElementById('countdownLabel')

        // new settings toggles
        const compactTimerToggle = document.getElementById('compactTimerToggle')
        const perJobRingToggle = document.getElementById('perJobRingToggle')
        const resumeNowBtn = document.getElementById('resumeNowBtn')
        const pauseBtn = document.getElementById('pauseBtn')

        const profileInputs = Array.from(
                document.querySelectorAll('.form-section input, .form-section select'),
        )

        const requiredFieldIds = ['fullName', 'email', 'phone']

        // Location autocomplete using Google Places API
        const locationInput = document.getElementById('location')
        const locationDropdown = document.getElementById('locationDropdown')
        let selectedIndex = -1
        let debounceTimer = null
        let currentPredictions = []
        const GOOGLE_PLACES_API_KEY = 'AIzaSyDummyKeyForPlaceholder' // User will need to add their own key

        // Setup ARIA attributes
        if (locationInput && locationDropdown) {
                locationInput.setAttribute('role', 'combobox')
                locationInput.setAttribute('aria-autocomplete', 'list')
                locationInput.setAttribute('aria-expanded', 'false')
                locationInput.setAttribute('aria-controls', 'locationDropdown')
                locationDropdown.setAttribute('role', 'listbox')

                // Input handler with debouncing
                locationInput.addEventListener('input', (e) => {
                        clearTimeout(debounceTimer)
                        debounceTimer = setTimeout(() => {
                                const query = e.target.value.trim()
                                if (query.length < 2) {
                                        hideLocationDropdown()
                                        return
                                }
                                fetchGooglePlacesPredictions(query)
                        }, 300)
                })

                // Keyboard navigation
                locationInput.addEventListener('keydown', (e) => {
                        if (!locationDropdown.classList.contains('active')) return

                        switch (e.key) {
                                case 'ArrowDown':
                                        e.preventDefault()
                                        selectedIndex = Math.min(selectedIndex + 1, currentPredictions.length - 1)
                                        updateLocationHighlight()
                                        break
                                case 'ArrowUp':
                                        e.preventDefault()
                                        selectedIndex = Math.max(selectedIndex - 1, -1)
                                        updateLocationHighlight()
                                        break
                                case 'Enter':
                                        e.preventDefault()
                                        if (selectedIndex >= 0 && currentPredictions[selectedIndex]) {
                                                selectLocation(currentPredictions[selectedIndex])
                                        }
                                        break
                                case 'Escape':
                                        e.preventDefault()
                                        hideLocationDropdown()
                                        break
                        }
                })

                // Close dropdown when clicking outside
                document.addEventListener('click', (e) => {
                        if (!e.target.closest('.location-autocomplete')) {
                                hideLocationDropdown()
                        }
                })
        }

        async function fetchGooglePlacesPredictions(query) {
                try {
                        // Send message to background script to fetch predictions
                        // This bypasses CORS restrictions in Manifest V3
                        chrome.runtime.sendMessage({
                                action: 'getPlacePredictions',
                                query: query
                        }, (response) => {
                                if (chrome.runtime.lastError) {
                                        console.error('Extension error:', chrome.runtime.lastError)
                                        hideLocationDropdown()
                                        return
                                }
                                
                                if (response && response.success && response.predictions) {
                                        // Format results as: City, State, Country
                                        currentPredictions = response.predictions.map(p => ({
                                                description: p.description,
                                                placeId: p.place_id
                                        }))
                                        displayLocationDropdown()
                                } else if (response && response.error) {
                                        console.error('Google Places API error:', response.error)
                                        hideLocationDropdown()
                                } else {
                                        hideLocationDropdown()
                                }
                        })
                } catch (error) {
                        console.error('Error fetching Google Places:', error)
                        hideLocationDropdown()
                }
        }

        function displayLocationDropdown() {
                locationDropdown.innerHTML = ''
                
                currentPredictions.forEach((prediction, index) => {
                        const option = document.createElement('div')
                        option.className = 'location-option'
                        option.textContent = prediction.description
                        option.setAttribute('role', 'option')
                        option.setAttribute('data-index', index)
                        
                        option.addEventListener('click', () => selectLocation(prediction))
                        option.addEventListener('mouseenter', () => {
                                selectedIndex = index
                                updateLocationHighlight()
                        })
                        
                        locationDropdown.appendChild(option)
                })
                
                locationDropdown.classList.add('active')
                locationInput.setAttribute('aria-expanded', 'true')
        }

        function updateLocationHighlight() {
                const options = locationDropdown.querySelectorAll('.location-option')
                options.forEach((opt, idx) => {
                        opt.classList.toggle('highlighted', idx === selectedIndex)
                        if (idx === selectedIndex) {
                                opt.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
                        }
                })
        }

        function selectLocation(prediction) {
                locationInput.value = prediction.description
                hideLocationDropdown()
                // Trigger input event to mark form as dirty
                locationInput.dispatchEvent(new Event('input', { bubbles: true }))
        }

        function hideLocationDropdown() {
                locationDropdown.classList.remove('active')
                locationInput.setAttribute('aria-expanded', 'false')
                selectedIndex = -1
        }

        const STATUS_CONFIG = {
                inactive: {
                        badge: 'Inactive',
                        className: 'inactive',
                        title: 'Ready to start',
                        hint: 'Fill your profile and start auto apply.',
                        buttonLabel: 'Start Auto Apply',
                },
                running: {
                        badge: 'Running',
                        className: 'running',
                        title: 'Auto applying…',
                        hint: 'Sit tight while Easy Apply completes.',
                        buttonLabel: 'Auto Applying…',
                },
                paused: {
                        badge: 'Paused',
                        className: 'paused',
                        title: 'Waiting for you',
                        hint: 'Finish the LinkedIn form or resume when ready.',
                        buttonLabel: 'Auto Applying…',
                },
                limit: {
                        badge: 'Limit Reached',
                        className: 'limit',
                        title: 'LinkedIn limit reached',
                        hint: 'LinkedIn is limiting applications. Please wait and try again later.',
                        buttonLabel: 'Start Auto Apply',
                },
        }

        const COUNTDOWN_LABEL_DEFAULT = 'sec'
        const DEFAULT_COUNTDOWN_HINT = 'Finish the LinkedIn form to keep things moving.'

        let userData = {}
        let activeJobTabId = null
        let runElapsedSeconds = 0
        let runTimerInterval = null
        let countdownInterval = null
        let countdownRemaining = 0
        let countdownTotal = 0
        let currentState = 'inactive'
        let formDirty = false
        let formValid = false
        let profileSaved = false

        resumeNowBtn.disabled = true
        pauseBtn.disabled = true
        updateCountdownState('idle')
        updateCountdownDisplay()
        updateStatusUI('inactive')

        profileInputs.forEach((input) => {
                input.addEventListener('input', handleFormFieldInput)
                input.addEventListener('change', handleFormFieldInput)
        })

        saveSettingsBtn.disabled = true
        startBtn.disabled = true

        chrome.storage.sync.get('userData', (data) => {
                userData = data.userData || {}
                fillForm(userData)
                initializeFormState(userData)
        })

        // initialize settings toggles from local storage
        chrome.storage.local.get({ compactTimer: false, perJobRing: false }, (res) => {
                if (compactTimerToggle) compactTimerToggle.checked = !!res.compactTimer
                if (perJobRingToggle) perJobRingToggle.checked = !!res.perJobRing
        })

        // send settings to content script when toggles change
        if (compactTimerToggle) {
                compactTimerToggle.addEventListener('change', async () => {
                        await chrome.storage.local.set({ compactTimer: compactTimerToggle.checked })
                        sendSettingsToContent({ compactTimer: compactTimerToggle.checked })
                })
        }
        if (perJobRingToggle) {
                perJobRingToggle.addEventListener('change', async () => {
                        await chrome.storage.local.set({ perJobRing: perJobRingToggle.checked })
                        sendSettingsToContent({ perJobRing: perJobRingToggle.checked })
                })
        }

        await hydrateStats()
        updateRunTimerDisplay()

        chrome.storage.onChanged.addListener((changes, areaName) => {
                if (areaName !== 'local') return
                if (changes.appliedCount) {
                        appliedCountEl.textContent = changes.appliedCount.newValue ?? 0
                }
                if (changes.skippedCount) {
                        skippedCountEl.textContent = changes.skippedCount.newValue ?? 0
                }
        })

        saveSettingsBtn.addEventListener('click', async () => {
                const data = collectFormData()
                if (!validateUserData(data, { showAlert: true })) return
                await chrome.storage.sync.set({ userData: data })
                userData = data
                profileSaved = true
                formDirty = false
                formValid = true
                applyValidationStyles([], { show: false })
                updateSaveButtonState()
                updateActionButtons()
                alert('✅ Profile saved successfully!')
        })

        addSkillBtn.addEventListener('click', () => addSkillRow(undefined, { silent: false }))

        // Reset button: clear stats and profile after confirmation
        if (resetBtn) {
                resetBtn.addEventListener('click', async () => {
                        if (!confirm('Reset extension? This will clear counts and saved profile.')) return
                        // stop any running process
                        await stopAutoApply()
                        try {
                                await new Promise((resolve) => chrome.storage.local.set({ appliedCount: 0, skippedCount: 0 }, resolve))
                        } catch (e) {
                                console.debug('Failed to reset local stats:', e)
                        }
                        // remove saved profile
                        try {
                                await new Promise((resolve) => chrome.storage.sync.remove('userData', resolve))
                        } catch (e) {
                                console.debug('Failed to remove userData from sync storage:', e)
                                // fallback: set empty userData
                                try {
                                        await new Promise((resolve) => chrome.storage.sync.set({ userData: {} }, resolve))
                                } catch (err) { }
                        }
                        appliedCountEl.textContent = 0
                        skippedCountEl.textContent = 0
                        runElapsedSeconds = 0
                        updateRunTimerDisplay()
                        fillForm({})
                        initializeFormState({})
                        alert('✅ Extension reset complete')
                })
        }

        startBtn.addEventListener('click', async () => {
                if (!profileSaved) {
                        const data = collectFormData()
                        const valid = validateUserData(data, { showAlert: true })
                        if (valid) {
                                alert('ℹ️ Please save your profile before starting auto apply.')
                        }
                        return
                }

                const data = collectFormData()
                if (!validateUserData(data, { showAlert: true })) return
                userData = data
                await chrome.storage.sync.set({ userData })

                // Find all LinkedIn Jobs tabs in the current window and broadcast Start
                let tabs = []
                try {
                        const allTabs = await chrome.tabs.query({ currentWindow: true })
                        tabs = allTabs.filter((t) => isValidLinkedInTab(t))
                } catch (e) {
                        console.debug('Failed to query tabs for start:', e)
                }
                if (!tabs.length) {
                        alert('⚠️ Please open at least one LinkedIn job search tab before starting.')
                        return
                }
                activeJobTabId = tabs[0].id

                // Do not reset stats automatically when starting. User's counts should persist.
                updateStatusUI('running')

                try {
                        // include current settings when starting
                        const settings = await new Promise((resolve) =>
                                chrome.storage.local.get({ compactTimer: false, perJobRing: false }, resolve),
                        )
                        console.debug('Popup: broadcasting startAutoApply to', tabs.length, 'tabs', { settings })
                        for (const t of tabs) {
                                try {
                                        await chrome.tabs.sendMessage(t.id, {
                                                action: 'startAutoApply',
                                                userData,
                                                settings,
                                        })
                                } catch (err) {
                                        console.debug('Failed to send start to tab', t.id, err)
                                }
                        }
                } catch (error) {
                        console.error('Failed to broadcast start to content scripts:', error)
                        updateStatusUI('inactive')
                        alert(
                                '⚠️ Unable to start. Make sure a LinkedIn jobs tab is open and refreshed.',
                        )
                }
        })

        stopBtn.addEventListener('click', () => stopAutoApply())
        resumeNowBtn.addEventListener('click', () => resumeAutoApply(false))
        pauseBtn.addEventListener('click', () => pauseAutoApply())

        chrome.runtime.onMessage.addListener((request, sender) => {
                if (sender?.tab?.id) activeJobTabId = sender.tab.id
                switch (request.action) {
                        case 'updateStats':
                                if (typeof request.applied === 'number') {
                                        appliedCountEl.textContent = request.applied
                                }
                                if (typeof request.skipped === 'number') {
                                        skippedCountEl.textContent = request.skipped
                                }
                                if (
                                        (currentState !== 'paused' || !request.isRunning) &&
                                        !(currentState === 'limit' && request.isRunning)
                                ) {
                                        updateStatusUI(request.isRunning ? 'running' : 'inactive')
                                }
                                break
                        case 'manualPause':
                                updateStatusUI('paused')
                                startCountdown(request.seconds || 15, request.reason)
                                break
                        case 'manualPauseCleared':
                                clearCountdown()
                                if (typeof request.isRunning === 'boolean') {
                                        updateStatusUI(request.isRunning ? 'running' : 'inactive')
                                } else if (currentState === 'paused') {
                                        updateStatusUI('running')
                                }
                                break
                        case 'linkedinLimitReached':
                                clearCountdown()
                                updateStatusUI('limit')
                                alert(
                                        '⚠️ LinkedIn reports you have reached an apply limit. Please wait before continuing.',
                                )
                                break
                }
        })

        async function sendSettingsToContent(settings) {
                // Broadcast settings to all LinkedIn Jobs tabs in the current window
                try {
                        const allTabs = await chrome.tabs.query({ currentWindow: true })
                        const target = allTabs.filter((t) => isValidLinkedInTab(t))
                        for (const t of target) {
                                try {
                                        await chrome.tabs.sendMessage(t.id, { action: 'updateSettings', settings })
                                } catch (err) {
                                        console.debug('Failed to send settings to tab', t.id, err)
                                }
                        }
                } catch (err) {
                        console.debug('Failed to broadcast settings to content scripts:', err)
                }
        }

        function fillForm(data) {
                document.getElementById('fullName').value = data.fullName || ''
                document.getElementById('email').value = data.email || ''
                document.getElementById('phone').value = data.phone || ''
                document.getElementById('location').value = data.location || ''
                document.getElementById('linkedinProfile').value = data.linkedinProfile || ''
                document.getElementById('yearsExperience').value = data.yearsExperience || ''
                document.getElementById('currentCompany').value = data.currentCompany || ''
                document.getElementById('currentTitle').value = data.currentTitle || ''
                document.getElementById('noticePeriod').value = data.noticePeriod || ''
                document.getElementById('workAuthorization').value =
                        data.workAuthorization || ''
                document.getElementById('gender').value = data.gender || ''
                document.getElementById('disability').value = data.disability || ''
                document.getElementById('willingToRelocate').checked = data.willingToRelocate || false

                skillsContainer.innerHTML = ''
                        ; (data.skills || []).forEach((skill) => addSkillRow(skill))
        }

        function collectFormData() {
                const skills = Array.from(
                        skillsContainer.querySelectorAll('.skill-row'),
                )
                        .map((row) => ({
                                name: row.querySelector('.skill-name').value.trim(),
                                hasSkill: row.querySelector('.skill-yes').checked,
                                experience: row.querySelector('.skill-exp').value.trim() || '0',
                        }))
                        .filter((skill) => skill.name)
                return {
                        fullName: document.getElementById('fullName').value.trim(),
                        email: document.getElementById('email').value.trim(),
                        phone: document.getElementById('phone').value.trim(),
                        location: document.getElementById('location').value.trim(),
                        linkedinProfile: document.getElementById('linkedinProfile').value.trim(),
                        yearsExperience: document.getElementById('yearsExperience').value.trim(),
                        currentCompany: document.getElementById('currentCompany').value.trim(),
                        currentTitle: document.getElementById('currentTitle').value.trim(),
                        noticePeriod: document.getElementById('noticePeriod').value.trim(),
                        workAuthorization: document
                                .getElementById('workAuthorization')
                                .value.trim(),
                        gender: document.getElementById('gender').value.trim(),
                        disability: document.getElementById('disability').value.trim(),
                        willingToRelocate: document.getElementById('willingToRelocate').checked,
                        skills,
                }
        }

        // Run timer is managed via updateStatusUI which controls start/stop based on currentState.
        // (Removed stray reference to undefined `state` which caused a ReferenceError.)

        function validateUserData(data, options = {}) {
                // options: { showAlert: boolean }
                const requiredFields = ['fullName', 'email', 'phone']
                const missing = requiredFields.filter((f) => !data[f])
                if (missing.length) {
                        if (options.showAlert) {
                                alert(`⚠️ Please fill required fields: ${missing.join(', ')}`)
                        }
                        return false
                }
                // Skills are now optional - extension will skip skill questions if none provided
                return true
        }

        function applyValidationStyles(missingFields = [], options = {}) {
                // Add/remove a simple 'invalid' class for required inputs
                const fields = ['fullName', 'email', 'phone']
                fields.forEach((id) => {
                        const el = document.getElementById(id)
                        if (!el) return
                        if (missingFields.includes(id)) el.classList.add('invalid')
                        else el.classList.remove('invalid')
                })
                if (options.show === false) {
                        // remove all invalid indicators
                        fields.forEach((id) => {
                                const el = document.getElementById(id)
                                if (el) el.classList.remove('invalid')
                        })
                }
        }

        function updateSaveButtonState() {
                // Enable save when the form is dirty and required fields are present
                try {
                        const data = collectFormData()
                        const hadRequired = ['fullName', 'email', 'phone'].every((f) => !!data[f])
                        saveSettingsBtn.disabled = !(formDirty && hadRequired)
                } catch (e) {
                        saveSettingsBtn.disabled = true
                }
        }

        function updateActionButtons() {
                // Start button should be enabled only when profileSaved is true and not running
                if (!startBtn) return
                if (currentState === 'running') {
                        startBtn.disabled = true
                        stopBtn.disabled = false
                } else {
                        startBtn.disabled = !profileSaved
                        stopBtn.disabled = true
                }
        }

        function initializeFormState(data) {
                // Set initial flags based on stored data
                profileSaved = !!(data && Object.keys(data).length)
                formDirty = false
                formValid = profileSaved && validateUserData(data, { showAlert: false })
                applyValidationStyles([], { show: false })
                updateSaveButtonState()
                updateActionButtons()
        }

        function handleFormFieldInput(e) {
                // mark form as dirty and disable profileSaved until saved
                formDirty = true
                profileSaved = false
                // update UI affordances
                updateSaveButtonState()
                updateActionButtons()
                // remove validation hints while editing
                applyValidationStyles([], { show: false })
        }

        function addSkillRow(skill = { name: '', hasSkill: true, experience: '' }, options = {}) {
                // options: { silent: boolean } - when true, don't mark form dirty
                const row = document.createElement('div')
                row.className = 'skill-row'

                const nameInput = document.createElement('input')
                nameInput.type = 'text'
                nameInput.className = 'skill-name'
                nameInput.placeholder = 'Skill (e.g., React)'
                nameInput.value = skill.name || ''

                const toggleLabel = document.createElement('label')
                toggleLabel.className = 'skill-toggle'
                const toggleInput = document.createElement('input')
                toggleInput.type = 'checkbox'
                toggleInput.className = 'skill-yes'
                toggleInput.checked = skill.hasSkill !== false
                const toggleText = document.createElement('span')
                toggleText.textContent = 'Have Skill'
                toggleLabel.append(toggleInput, toggleText)

                const experienceInput = document.createElement('input')
                experienceInput.type = 'number'
                experienceInput.className = 'skill-exp'
                experienceInput.placeholder = 'Years'
                experienceInput.min = '0'
                experienceInput.value = skill.experience || '0'

                const removeBtn = document.createElement('button')
                removeBtn.type = 'button'
                removeBtn.className = 'remove-skill'
                removeBtn.textContent = '✕'
                removeBtn.setAttribute('aria-label', 'Remove skill')
                removeBtn.addEventListener('click', () => {
                        row.remove()
                        // mark dirty and update buttons
                        formDirty = true
                        profileSaved = false
                        updateSaveButtonState()
                        updateActionButtons()
                })

                // Attach listeners so editing a newly added skill marks form dirty
                nameInput.addEventListener('input', handleFormFieldInput)
                toggleInput.addEventListener('change', handleFormFieldInput)
                experienceInput.addEventListener('input', handleFormFieldInput)

                row.append(nameInput, toggleLabel, experienceInput, removeBtn)
                skillsContainer.appendChild(row)

                if (!options.silent) {
                        formDirty = true
                        profileSaved = false
                        updateSaveButtonState()
                        updateActionButtons()
                        // focus the new skill input for convenience
                        nameInput.focus()
                }
        }

        function updateStatusUI(state, overrides = {}) {
                if (currentState === 'paused' && state === 'running' && countdownInterval)
                        return
                currentState = state
                const config = STATUS_CONFIG[state] || STATUS_CONFIG.inactive
                const badgeText = overrides.badge || config.badge
                const statusClass = `status-pill status-pill--${config.className}`
                const hint = overrides.hint || config.hint
                const title = overrides.title || config.title
                const buttonLabel = overrides.buttonLabel || config.buttonLabel

                if (statusBadge) {
                        statusBadge.textContent = badgeText
                        statusBadge.className = statusClass
                }
                if (statusText) statusText.textContent = title
                setStatusHint(hint)

                switch (state) {
                        case 'running':
                                startBtn.disabled = true
                                stopBtn.disabled = false
                                setButtonLoading(true, buttonLabel)
                                resumeNowBtn.disabled = true
                                pauseBtn.disabled = true
                                break
                        case 'paused':
                                startBtn.disabled = true
                                stopBtn.disabled = false
                                setButtonLoading(true, buttonLabel)
                                break
                        case 'limit':
                                startBtn.disabled = false
                                stopBtn.disabled = true
                                setButtonLoading(false)
                                resumeNowBtn.disabled = true
                                pauseBtn.disabled = true
                                break
                        default:
                                startBtn.disabled = false
                                stopBtn.disabled = true
                                setButtonLoading(false)
                                resumeNowBtn.disabled = true
                                pauseBtn.disabled = true
                }

                // Manage run timer: run only while in 'running' state
                if (state === 'running') startRunTimer()
                else stopRunTimer()
        }

        // Running time helpers
        function formatSecsToMinSec(sec) {
                if (typeof sec !== 'number' || Number.isNaN(sec)) return '--'
                const m = Math.floor(sec / 60)
                const s = sec % 60
                if (m > 0) return `${m}m ${String(s).padStart(2, '0')}s`
                return `${s}s`
        }

        function startRunTimer() {
                if (!runTimerEl) return
                if (runTimerInterval) return // already running
                runTimerInterval = setInterval(() => {
                        runElapsedSeconds += 1
                        updateRunTimerDisplay()
                }, 1000)
                updateRunTimerDisplay()
        }

        function stopRunTimer() {
                if (runTimerInterval) {
                        clearInterval(runTimerInterval)
                        runTimerInterval = null
                }
        }

        function updateRunTimerDisplay() {
                if (!runTimerEl) return
                runTimerEl.textContent = formatSecsToMinSec(runElapsedSeconds)
        }

        function setButtonLoading(isLoading, labelText = 'Auto Applying…') {
                if (!startBtn) return
                if (isLoading) {
                        startBtn.classList.add('btn--loading')
                        if (startBtnLabel) startBtnLabel.textContent = labelText
                        else startBtn.textContent = labelText
                } else {
                        startBtn.classList.remove('btn--loading')
                        if (startBtnLabel) startBtnLabel.textContent = 'Start Auto Apply'
                        else startBtn.textContent = 'Start Auto Apply'
                }
        }

        function setStatusHint(message) {
                if (!statusHint) return
                statusHint.textContent = message
        }

        function startCountdown(seconds, reason) {
                clearCountdown({ keepHint: true })
                countdownTotal = Math.max(1, Math.round(seconds))
                countdownRemaining = countdownTotal
                updateCountdownState('counting')
                updateCountdownDisplay()
                setStatusHint(getCountdownHint(reason))
                resumeNowBtn.disabled = false
                pauseBtn.disabled = false
                if (countdownContainer) countdownContainer.classList.add('is-active')

                countdownInterval = setInterval(() => {
                        countdownRemaining -= 1
                        if (countdownRemaining <= 0) {
                                clearCountdown()
                                resumeAutoApply(true)
                                return
                        }
                        updateCountdownDisplay()
                }, 1000)
        }

        function pauseAutoApply() {
                if (currentState !== 'paused') return
                // Stop the countdown interval to prevent auto-resume
                cancelCountdownInterval()
                updateCountdownState('paused')
                // Keep displaying the remaining time
                updateCountdownDisplay()
                resumeNowBtn.disabled = false
                pauseBtn.disabled = true
                setStatusHint('Auto apply paused. Resume when ready.')
        }

        function clearCountdown(options = {}) {
                cancelCountdownInterval()
                countdownTotal = 0
                countdownRemaining = 0
                updateCountdownState('idle')
                if (!options.skipDisplayReset) updateCountdownDisplay()
                resumeNowBtn.disabled = true
                pauseBtn.disabled = true
                if (countdownRing) countdownRing.style.setProperty('--ring-progress', '0')
                if (countdownContainer) countdownContainer.classList.remove('is-active')
                if (!options.keepHint) {
                        const config = STATUS_CONFIG[currentState] || STATUS_CONFIG.inactive
                        setStatusHint(config.hint)
                }
        }

        function cancelCountdownInterval() {
                if (countdownInterval) {
                        clearInterval(countdownInterval)
                        countdownInterval = null
                }
        }

        function updateCountdownState(state) {
                if (countdownRing) countdownRing.dataset.state = state
        }

        function updateCountdownDisplay() {
                if (!countdownValueEl || !countdownLabelEl) return
                if (countdownRing?.dataset.state === 'paused') {
                        // Show timer text even when paused
                        const mins = Math.floor(countdownRemaining / 60)
                        const secs = countdownRemaining % 60
                        countdownValueEl.textContent = `${mins}:${secs.toString().padStart(2, '0')}`
                        countdownLabelEl.textContent = 'paused'
                        return
                }
                if (!countdownTotal || countdownRemaining <= 0) {
                        countdownValueEl.textContent = '--'
                        countdownLabelEl.textContent = COUNTDOWN_LABEL_DEFAULT
                        if (countdownRing) countdownRing.style.setProperty('--ring-progress', '0')
                        return
                }
                countdownValueEl.textContent = countdownRemaining
                countdownLabelEl.textContent = COUNTDOWN_LABEL_DEFAULT
                const degrees = Math.max(
                        0,
                        Math.min(360, (countdownRemaining / countdownTotal) * 360),
                )
                if (countdownRing)
                        countdownRing.style.setProperty('--ring-progress', degrees.toFixed(2))
        }

        function getCountdownHint(reason) {
                switch (reason) {
                        case 'formIncomplete':
                                return 'Finish missing answers in the LinkedIn form.'
                        default:
                                return DEFAULT_COUNTDOWN_HINT
                }
        }

        async function stopAutoApply() {
                clearCountdown()
                updateStatusUI('inactive')
                // send stop to all LinkedIn Jobs tabs so they all cleanup
                try {
                        const allTabs = await chrome.tabs.query({ currentWindow: true })
                        const target = allTabs.filter((t) => isValidLinkedInTab(t))
                        for (const t of target) {
                                try {
                                        await chrome.tabs.sendMessage(t.id, { action: 'stopAutoApply' })
                                } catch (err) {
                                        console.debug('Failed to send stop to tab', t.id, err)
                                }
                        }
                } catch (err) {
                        console.debug('Failed to broadcast stop:', err)
                }
                // also reset popup run timer
                runElapsedSeconds = 0
                updateRunTimerDisplay()
        }

        async function resumeAutoApply(autoTriggered) {
                clearCountdown()
                updateStatusUI('running')
                const tab = await getJobTab()
                if (!tab) return
                try {
                        await chrome.tabs.sendMessage(tab.id, {
                                action: 'manualResume',
                                autoTriggered: Boolean(autoTriggered),
                        })
                } catch (error) {
                        console.warn('Unable to send resume message:', error)
                }
        }

        async function getJobTab() {
                if (activeJobTabId) {
                        try {
                                const tab = await chrome.tabs.get(activeJobTabId)
                                if (tab && isValidLinkedInTab(tab)) return tab
                        } catch (error) {
                                console.debug('Stored tab no longer available:', error)
                        }
                }
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
                if (tab && isValidLinkedInTab(tab)) {
                        activeJobTabId = tab.id
                        return tab
                }
                return null
        }

        async function hydrateStats() {
                const { appliedCount = 0, skippedCount = 0 } = await chrome.storage.local.get([
                        'appliedCount',
                        'skippedCount',
                ])
                appliedCountEl.textContent = appliedCount
                skippedCountEl.textContent = skippedCount
        }

        async function resetStats() {
                await chrome.storage.local.set({ appliedCount: 0, skippedCount: 0 })
                appliedCountEl.textContent = 0
                skippedCountEl.textContent = 0
        }

        function isValidLinkedInTab(tab) {
                if (!tab || !tab.url) return false
                // Accept linkedin jobs pages with or without www and with either http/https
                return /^https?:\/\/(?:www\.)?linkedin\.com\/jobs\//.test(tab.url)
        }

        // ================ HISTORY TAB FUNCTIONALITY ================
        
        const tabButtons = document.querySelectorAll('.tab-btn')
        const tabContents = document.querySelectorAll('.tab-content')
        const historyTableBody = document.getElementById('historyTableBody')
        const historySearch = document.getElementById('historySearch')
        const historyFilter = document.getElementById('historyFilter')
        const historyTotal = document.getElementById('historyTotal')
        const historyApplied = document.getElementById('historyApplied')
        const historySkipped = document.getElementById('historySkipped')
        const exportHistoryBtn = document.getElementById('exportHistoryBtn')
        const clearHistoryBtn = document.getElementById('clearHistoryBtn')
        const historyPrevPage = document.getElementById('historyPrevPage')
        const historyNextPage = document.getElementById('historyNextPage')
        const historyPageInfo = document.getElementById('historyPageInfo')
        
        let jobHistory = []
        let filteredHistory = []
        let currentPage = 1
        const itemsPerPage = 20
        
        // Tab switching
        tabButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                        const targetTab = btn.dataset.tab
                        
                        tabButtons.forEach(b => b.classList.remove('active'))
                        tabContents.forEach(c => c.classList.remove('active'))
                        
                        btn.classList.add('active')
                        document.getElementById(targetTab + 'Tab').classList.add('active')
                        
                        if (targetTab === 'history') {
                                loadHistory()
                        }
                })
        })
        
        // Load and display history
        async function loadHistory() {
                try {
                        const { jobHistory: history = [] } = await chrome.storage.local.get(['jobHistory'])
                        jobHistory = history
                        filteredHistory = jobHistory
                        updateHistoryStats()
                        applyFilters()
                } catch (e) {
                        console.error('Failed to load history:', e)
                }
        }
        
        function updateHistoryStats() {
                historyTotal.textContent = jobHistory.length
                const appliedCount = jobHistory.filter(j => j.status === 'applied').length
                const skippedCount = jobHistory.filter(j => j.status && j.status.includes('skipped')).length
                historyApplied.textContent = appliedCount
                historySkipped.textContent = skippedCount
        }
        
        function applyFilters() {
                const searchTerm = historySearch?.value.toLowerCase() || ''
                const filterStatus = historyFilter?.value || 'all'
                
                filteredHistory = jobHistory.filter(job => {
                        const matchesSearch = !searchTerm || 
                                job.jobTitle.toLowerCase().includes(searchTerm) ||
                                job.company.toLowerCase().includes(searchTerm)
                        
                        const matchesFilter = filterStatus === 'all' || 
                                job.status === filterStatus ||
                                (filterStatus === 'skipped' && job.status && job.status.includes('skipped'))
                        
                        return matchesSearch && matchesFilter
                })
                
                currentPage = 1
                renderHistory()
        }
        
        function renderHistory() {
                if (!historyTableBody) return
                
                if (filteredHistory.length === 0) {
                        historyTableBody.innerHTML = '<tr class="history-empty"><td colspan="5">No jobs match your filters.</td></tr>'
                        updatePagination()
                        return
                }
                
                const startIndex = (currentPage - 1) * itemsPerPage
                const endIndex = startIndex + itemsPerPage
                const pageJobs = filteredHistory.slice(startIndex, endIndex)
                
                historyTableBody.innerHTML = pageJobs.map(job => {
                        const statusClass = getStatusClass(job.status)
                        const statusLabel = getStatusLabel(job.status)
                        const date = new Date(job.appliedAt || job.timestamp).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                        })
                        
                        return `
                                <tr>
                                        <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${job.jobTitle}">${job.jobTitle}</td>
                                        <td style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${job.company}">${job.company}</td>
                                        <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
                                        <td style="white-space: nowrap;">${date}</td>
                                        <td><a href="${job.jobLink}" class="job-link" target="_blank">View</a></td>
                                </tr>
                        `
                }).join('')
                
                updatePagination()
        }
        
        function getStatusClass(status) {
                if (status === 'applied') return 'status-badge--applied'
                if (status === 'failed') return 'status-badge--failed'
                if (status === 'stopped') return 'status-badge--stopped'
                return 'status-badge--skipped'
        }
        
        function getStatusLabel(status) {
                if (status === 'applied') return 'Applied'
                if (status === 'failed') return 'Failed'
                if (status === 'stopped') return 'Stopped'
                if (status === 'already_applied') return 'Already Applied'
                if (status === 'skipped_no_easy_apply') return 'No Easy Apply'
                if (status === 'skipped_modal_failed') return 'Modal Failed'
                if (status === 'skipped_load_failed') return 'Load Failed'
                if (status === 'skipped_max_attempts') return 'Max Attempts'
                return 'Skipped'
        }
        
        function updatePagination() {
                const totalPages = Math.ceil(filteredHistory.length / itemsPerPage)
                historyPageInfo.textContent = `Page ${currentPage} of ${totalPages || 1}`
                historyPrevPage.disabled = currentPage <= 1
                historyNextPage.disabled = currentPage >= totalPages
        }
        
        // Event listeners for history controls
        if (historySearch) {
                historySearch.addEventListener('input', applyFilters)
        }
        
        if (historyFilter) {
                historyFilter.addEventListener('change', applyFilters)
        }
        
        if (historyPrevPage) {
                historyPrevPage.addEventListener('click', () => {
                        if (currentPage > 1) {
                                currentPage--
                                renderHistory()
                        }
                })
        }
        
        if (historyNextPage) {
                historyNextPage.addEventListener('click', () => {
                        const totalPages = Math.ceil(filteredHistory.length / itemsPerPage)
                        if (currentPage < totalPages) {
                                currentPage++
                                renderHistory()
                        }
                })
        }
        
        // Export history to CSV
        if (exportHistoryBtn) {
                exportHistoryBtn.addEventListener('click', () => {
                        if (jobHistory.length === 0) {
                                alert('No history to export.')
                                return
                        }
                        
                        const csvContent = [
                                ['Job Title', 'Company', 'Status', 'Date', 'Link'],
                                ...jobHistory.map(job => [
                                        job.jobTitle,
                                        job.company,
                                        getStatusLabel(job.status),
                                        new Date(job.appliedAt || job.timestamp).toISOString(),
                                        job.jobLink
                                ])
                        ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n')
                        
                        const blob = new Blob([csvContent], { type: 'text/csv' })
                        const url = URL.createObjectURL(blob)
                        const a = document.createElement('a')
                        a.href = url
                        a.download = `linkedin-job-history-${new Date().toISOString().split('T')[0]}.csv`
                        document.body.appendChild(a)
                        a.click()
                        document.body.removeChild(a)
                        URL.revokeObjectURL(url)
                })
        }
        
        // Clear history
        if (clearHistoryBtn) {
                clearHistoryBtn.addEventListener('click', async () => {
                        if (!confirm('Are you sure you want to clear all job history? This cannot be undone.')) {
                                return
                        }
                        
                        try {
                                await chrome.storage.local.set({ jobHistory: [] })
                                jobHistory = []
                                filteredHistory = []
                                updateHistoryStats()
                                renderHistory()
                                alert('History cleared successfully.')
                        } catch (e) {
                                console.error('Failed to clear history:', e)
                                alert('Failed to clear history. Please try again.')
                        }
                })
        }
        
        // Listen for history updates from content script
        chrome.storage.onChanged.addListener((changes, areaName) => {
                if (areaName === 'local' && changes.jobHistory) {
                        // Only reload history if the History tab is currently active
                        const historyTab = document.getElementById('historyTab')
                        if (historyTab && historyTab.classList.contains('active')) {
                                loadHistory()
                        }
                }
        })
})

